<?php

return [
    // 
    'new' => 'New|New',
    'manage' => 'Manage',
    'save' => 'Save',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'cancel' => 'Cancel',
    'add' => 'Add',

    'select' => 'Select a',
    'search' => 'Search for',
    'confirm' => 'Confirm',
    'perPage' => 'Per page',
    'loading' => 'Loading...',

];
