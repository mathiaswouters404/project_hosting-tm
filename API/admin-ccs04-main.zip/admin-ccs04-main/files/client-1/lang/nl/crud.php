<?php

return [
    //
    'new' => 'Nieuwe|Nieuw',
    'manage' => 'Beheer',
    'save' => 'Opslaan',
    'edit' => 'Bewerk',
    'delete' => 'Verwijder',
    'cancel' => 'annuleer',
    'add' => 'Toevoegen',

    'select' => 'Selecteer een',
    'search' => 'Zoeken op',
    'confirm' => 'Bevestig',
    'perPage' => 'Per pagina',
    'loading' => 'Laden...',
];
