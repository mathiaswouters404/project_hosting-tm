<?php

return [
    'en' => 'Engels',
    'nl' => 'Nederlands',
];
