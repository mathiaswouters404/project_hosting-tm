<?php

return [
    'Post Date' => 'Post Datum',
    'Announcements' => 'Mededeling|Mededelingen',
    'Not yet posted' => 'Nog niet geplaatst',
    'Title' => 'Titel',
    'Content' => 'Content',
    'close' => 'Sluiten',
    'view' => 'Bekijk',
    'click name' => "Klik op de titel voor meer informatie"
];
